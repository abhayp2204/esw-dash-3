import "./App.css";
import axios from "axios"
import React, { useState } from "react"
import Plot from "react-plotly.js"
import { DateTimePickerComponent } from "@syncfusion/ej2-react-calendars"
import { LocalizationProvider } from "@mui/x-date-pickers"
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns"
import CustomDateTimePicker from "./CustomDateTimePicker"
import Kettle from "./Kettle";
import Select from "./Select";
import Navbar from "./Navbar";

// Routes
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"

function App() {
    return (
        <div className="App">
            <Router>
                <Routes>
                    <Navbar />
                    <Route
                        path="/"
                        element={<Select field={1}/>}
                    />
                    <Route
                        path="/kettle"
                        element={<Kettle field={1}/>}
                    />
                    <Route
                        path="/hairdryer"
                        element={<Kettle field={2}/>}
                    />
                </Routes>
            </Router>
        </div>
    );
}

export default App;
