import "./App.css";
import React, { useState } from "react"
import { Link } from "react-router-dom"
import KettleImage from "./kettle.png"
import HairDryerImage from "./HairDryer.png"

const cardStyle = {
    color: "white",
    textDecoration: "none",
    cursor: "default",
}

function Select() {
    return (
        <html>
            <body>
                <div className="select-container">
                    <div className="cards">
                        <Link style={cardStyle} to="kettle"><img src={KettleImage} /></Link>
                    </div>
                    <div className="cards">
                        <Link style={cardStyle} to="hairdryer"><img src={HairDryerImage} /></Link>
                    </div>
                </div>
            </body>
        </html>
    );
}

export default Select;
